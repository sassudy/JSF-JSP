package beans;
/**
 *
 * @author kcass
 */
import java.net.*;


public class Bean implements java.io.Serializable{
    public Bean(){}
    
    public static String getIP() throws UnknownHostException{
        String ip = "";
        InetAddress inetAddress = InetAddress.getLocalHost();
        ip = inetAddress.getHostAddress();
        return ip;
    }
    public static String getName() throws UnknownHostException{
        String name = "";
        InetAddress inetAddress = InetAddress.getLocalHost();
        name = inetAddress.getHostName();
        return name;
    }   
}
